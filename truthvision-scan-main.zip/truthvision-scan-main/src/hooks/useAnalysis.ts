import { useState, useCallback } from 'react';
import { MediaType } from '@/types/media';

export interface AnalysisResultData {
  mediaType: MediaType;
  isReal: boolean;
  confidence: number;
  details: Record<string, number>;
  processingTime: number;
}

const METRICS_BY_TYPE: Record<MediaType, string[]> = {
  video: ['facialConsistency', 'temporalCoherence', 'audioVisualSync', 'compressionArtifacts'],
  image: ['pixelAnomalies', 'facialFeatures', 'lightingConsistency', 'metadataIntegrity'],
  audio: ['voicePatterns', 'spectralAnalysis', 'breathingPatterns', 'backgroundNoise'],
  text: ['perplexityScore', 'burstiness', 'vocabularyPatterns', 'sentenceStructure'],
};

const METRIC_LABELS: Record<string, string> = {
  // Video
  facialConsistency: 'Facial Consistency',
  temporalCoherence: 'Temporal Coherence',
  audioVisualSync: 'Audio-Visual Sync',
  compressionArtifacts: 'Compression Analysis',
  // Image
  pixelAnomalies: 'Pixel Anomalies',
  facialFeatures: 'Facial Features',
  lightingConsistency: 'Lighting Consistency',
  metadataIntegrity: 'Metadata Integrity',
  // Audio
  voicePatterns: 'Voice Patterns',
  spectralAnalysis: 'Spectral Analysis',
  breathingPatterns: 'Breathing Patterns',
  backgroundNoise: 'Background Noise',
  // Text
  perplexityScore: 'Perplexity Score',
  burstiness: 'Burstiness',
  vocabularyPatterns: 'Vocabulary Patterns',
  sentenceStructure: 'Sentence Structure',
};

export const getMetricLabel = (key: string): string => {
  return METRIC_LABELS[key] || key;
};

// Simulated AI analysis
const simulateAnalysis = (mediaType: MediaType): Promise<AnalysisResultData> => {
  return new Promise((resolve) => {
    const processingTime = 2 + Math.random() * 3;
    
    setTimeout(() => {
      const isReal = Math.random() > 0.4;
      const baseConfidence = isReal ? 75 + Math.random() * 20 : 70 + Math.random() * 25;
      
      const generateMetric = (isReal: boolean) => {
        const base = isReal ? 65 : 35;
        const variance = 25;
        return Math.min(95, Math.max(15, base + (Math.random() - 0.5) * variance));
      };

      const metrics = METRICS_BY_TYPE[mediaType];
      const details: Record<string, number> = {};
      
      metrics.forEach((metric) => {
        details[metric] = generateMetric(isReal);
      });

      resolve({
        mediaType,
        isReal,
        confidence: baseConfidence,
        details,
        processingTime,
      });
    }, processingTime * 1000);
  });
};

export const useAnalysis = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResultData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const analyze = useCallback(async (mediaType: MediaType, file?: File, text?: string) => {
    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      // In a real implementation, you would:
      // 1. Upload the file/text to a backend
      // 2. Call an ML inference API
      // 3. Return the actual detection results
      
      const analysisResult = await simulateAnalysis(mediaType);
      setResult(analysisResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Analysis failed');
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
    setIsAnalyzing(false);
  }, []);

  return {
    analyze,
    reset,
    isAnalyzing,
    result,
    error,
  };
};
