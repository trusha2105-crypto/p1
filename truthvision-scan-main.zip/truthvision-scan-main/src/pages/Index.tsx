import React, { useRef, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { MediaTypeSelector } from '@/components/MediaTypeSelector';
import { MediaUploader } from '@/components/MediaUploader';
import { AnalysisResult } from '@/components/AnalysisResult';
import { HowItWorks } from '@/components/HowItWorks';
import { Features } from '@/components/Features';
import { Footer } from '@/components/Footer';
import { useAnalysis } from '@/hooks/useAnalysis';
import { useToast } from '@/hooks/use-toast';
import { MediaType, MEDIA_CONFIGS } from '@/types/media';

const Index: React.FC = () => {
  const uploadRef = useRef<HTMLDivElement>(null);
  const [selectedMediaType, setSelectedMediaType] = useState<MediaType>('video');
  const { analyze, reset, isAnalyzing, result, error } = useAnalysis();
  const { toast } = useToast();

  const handleGetStarted = () => {
    uploadRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleMediaSelect = async (file: File | null, text?: string) => {
    const config = MEDIA_CONFIGS[selectedMediaType];

    if (selectedMediaType === 'text') {
      if (!text || text.trim().length < 50) {
        toast({
          title: "Text too short",
          description: "Please enter at least 50 characters",
          variant: "destructive",
        });
        return;
      }
      if (text.length > config.maxSize) {
        toast({
          title: "Text too long",
          description: `Please enter less than ${config.maxSizeLabel}`,
          variant: "destructive",
        });
        return;
      }
    } else {
      if (!file) return;
      
      if (file.size > config.maxSize) {
        toast({
          title: "File too large",
          description: `Please select a ${config.label.toLowerCase()} under ${config.maxSizeLabel}`,
          variant: "destructive",
        });
        return;
      }
    }

    await analyze(selectedMediaType, file || undefined, text);
    
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 500);
  };

  const handleReset = () => {
    reset();
    handleGetStarted();
  };

  return (
    <>
      <Helmet>
        <title>DeepDetect - AI Fake Media Detection | Video, Image, Audio, Text</title>
        <meta name="description" content="Detect AI-generated and fake content across video, image, audio, and text with advanced neural network analysis. Upload, scan, and get results in seconds." />
        <meta name="keywords" content="deepfake detection, AI detection, fake video detector, AI image detector, synthetic voice detection, AI text detection" />
        <link rel="canonical" href="https://deepdetect.app" />
        
        <meta property="og:title" content="DeepDetect - AI Fake Media Detection" />
        <meta property="og:description" content="Detect AI-generated content across video, image, audio, and text. Get results in seconds." />
        <meta property="og:type" content="website" />
        
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="DeepDetect - AI Fake Media Detection" />
        <meta name="twitter:description" content="Detect AI-generated content across all media types." />
      </Helmet>

      <div className="min-h-screen">
        <Header onGetStarted={handleGetStarted} />
        
        <main>
          {result ? (
            <div className="pt-24">
              <AnalysisResult result={result} onReset={handleReset} />
            </div>
          ) : (
            <>
              <Hero onGetStarted={handleGetStarted} />
              <div ref={uploadRef} className="py-12 px-4">
                <div className="text-center mb-8">
                  <h2 className="font-display text-2xl md:text-3xl font-bold mb-2">
                    <span className="text-foreground">SELECT </span>
                    <span className="text-gradient">MEDIA TYPE</span>
                  </h2>
                </div>
                <MediaTypeSelector
                  selected={selectedMediaType}
                  onSelect={setSelectedMediaType}
                  disabled={isAnalyzing}
                />
              </div>
              <MediaUploader
                mediaType={selectedMediaType}
                onMediaSelect={handleMediaSelect}
                isAnalyzing={isAnalyzing}
              />
              <HowItWorks />
              <Features />
            </>
          )}
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default Index;
