export type MediaType = 'video' | 'image' | 'audio' | 'text';

export interface MediaTypeConfig {
  type: MediaType;
  label: string;
  description: string;
  acceptedFormats: string;
  accept: string;
  maxSize: number; // in bytes
  maxSizeLabel: string;
}

export const MEDIA_CONFIGS: Record<MediaType, MediaTypeConfig> = {
  video: {
    type: 'video',
    label: 'Video',
    description: 'Detect deepfake and AI-generated videos',
    acceptedFormats: 'MP4, WebM, MOV',
    accept: 'video/*',
    maxSize: 100 * 1024 * 1024,
    maxSizeLabel: '100MB',
  },
  image: {
    type: 'image',
    label: 'Image',
    description: 'Detect AI-generated or manipulated images',
    acceptedFormats: 'JPG, PNG, WebP',
    accept: 'image/*',
    maxSize: 20 * 1024 * 1024,
    maxSizeLabel: '20MB',
  },
  audio: {
    type: 'audio',
    label: 'Audio',
    description: 'Detect synthetic or cloned voices',
    acceptedFormats: 'MP3, WAV, M4A',
    accept: 'audio/*',
    maxSize: 50 * 1024 * 1024,
    maxSizeLabel: '50MB',
  },
  text: {
    type: 'text',
    label: 'Text',
    description: 'Detect AI-generated text content',
    acceptedFormats: 'Paste or type text',
    accept: '',
    maxSize: 50000, // characters
    maxSizeLabel: '50K chars',
  },
};

export interface AnalysisMetrics {
  video: {
    facialConsistency: number;
    temporalCoherence: number;
    audioVisualSync: number;
    compressionArtifacts: number;
  };
  image: {
    pixelAnomalies: number;
    facialFeatures: number;
    lightingConsistency: number;
    metadataIntegrity: number;
  };
  audio: {
    voicePatterns: number;
    spectralAnalysis: number;
    breathingPatterns: number;
    backgroundNoise: number;
  };
  text: {
    perplexityScore: number;
    burstiness: number;
    vocabularyPatterns: number;
    sentenceStructure: number;
  };
}
