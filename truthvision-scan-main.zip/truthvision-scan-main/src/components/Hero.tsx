import React from 'react';
import { Button } from '@/components/ui/button';
import { ShieldIcon } from '@/components/icons/ShieldIcon';
import { ChevronDown, Shield, Zap, Eye } from 'lucide-react';

interface HeroProps {
  onGetStarted: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onGetStarted }) => {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden">
      {/* Animated grid background */}
      <div className="absolute inset-0 grid-pattern animate-grid-flow opacity-50" />
      
      {/* Radial gradient overlay */}
      <div className="absolute inset-0 bg-gradient-radial from-primary/5 via-transparent to-transparent" />
      
      {/* Floating particles effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-primary/30 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Logo/Icon */}
        <div className="mb-8 animate-float">
          <ShieldIcon className="w-24 h-24 md:w-32 md:h-32 mx-auto" />
        </div>

        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 mb-6 rounded-full border border-primary/30 bg-primary/5 backdrop-blur-sm">
          <Zap className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium text-primary">AI-Powered Detection</span>
        </div>

        {/* Main heading */}
        <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
          <span className="text-foreground">DEEP</span>
          <span className="text-gradient">DETECT</span>
        </h1>

        {/* Subtitle */}
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed">
          Detect AI-generated and manipulated content across video, image, audio, and text. 
          Upload, scan, and get results in seconds.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <Button 
            variant="hero" 
            size="xl" 
            onClick={onGetStarted}
            className="min-w-[200px]"
          >
            <Eye className="w-5 h-5 mr-2" />
            Start Detection
          </Button>
          <Button 
            variant="glass" 
            size="lg"
            onClick={() => document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Learn More
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto">
          <div className="text-center">
            <div className="font-display text-2xl md:text-3xl font-bold text-primary mb-1">99.2%</div>
            <div className="text-xs md:text-sm text-muted-foreground">Accuracy Rate</div>
          </div>
          <div className="text-center">
            <div className="font-display text-2xl md:text-3xl font-bold text-primary mb-1">&lt;5s</div>
            <div className="text-xs md:text-sm text-muted-foreground">Analysis Time</div>
          </div>
          <div className="text-center">
            <div className="font-display text-2xl md:text-3xl font-bold text-primary mb-1">10M+</div>
            <div className="text-xs md:text-sm text-muted-foreground">Videos Scanned</div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-6 h-6 text-muted-foreground" />
      </div>
    </section>
  );
};
