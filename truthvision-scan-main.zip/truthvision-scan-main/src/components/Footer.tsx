import React from 'react';
import { ShieldIcon } from '@/components/icons/ShieldIcon';
import { Github, Twitter, Mail } from 'lucide-react';
export const Footer: React.FC = () => {
  return <footer className="py-12 px-4 border-t border-border bg-card/30">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <ShieldIcon className="w-8 h-8" />
            <span className="font-display text-xl font-bold">
              <span className="text-foreground">DEEP</span>
              <span className="text-gradient">DETECT</span>
            </span>
          </div>

          {/* Links */}
          <nav className="flex items-center gap-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-primary transition-colors">About</a>
            <a href="#" className="hover:text-primary transition-colors">API Docs</a>
            <a href="#" className="hover:text-primary transition-colors">Privacy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms</a>
          </nav>

          {/* Social */}
          <div className="flex items-center gap-4">
            <a href="#" className="p-2 rounded-lg hover:bg-muted transition-colors">
              <Github className="w-5 h-5 text-muted-foreground hover:text-primary" />
            </a>
            <a href="#" className="p-2 rounded-lg hover:bg-muted transition-colors">
              <Twitter className="w-5 h-5 text-muted-foreground hover:text-primary" />
            </a>
            <a href="#" className="p-2 rounded-lg hover:bg-muted transition-colors">
              <Mail className="w-5 h-5 text-muted-foreground hover:text-primary" />
            </a>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>© 2024 DeepDetect. Built for hackathon demonstration purposes.</p>
          <p className="mt-2 text-xs">
            Developed by <span className="text-primary font-medium">Harsh Rangari</span> & <span className="text-primary font-medium">Trusha Agre</span>
          </p>
          
        </div>
      </div>
    </footer>;
};