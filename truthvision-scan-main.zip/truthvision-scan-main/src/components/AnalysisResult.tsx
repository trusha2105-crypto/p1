import React from 'react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { ShieldCheck, ShieldAlert, RefreshCw, Download, CheckCircle2, XCircle, Video, Image, Mic, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';
import { AnalysisResultData, getMetricLabel } from '@/hooks/useAnalysis';
import { MediaType } from '@/types/media';

interface AnalysisResultProps {
  result: AnalysisResultData;
  onReset: () => void;
}

const MEDIA_ICONS: Record<MediaType, React.ElementType> = {
  video: Video,
  image: Image,
  audio: Mic,
  text: FileText,
};

const VERDICT_LABELS: Record<MediaType, { real: string; fake: string }> = {
  video: { real: 'AUTHENTIC VIDEO', fake: 'DEEPFAKE DETECTED' },
  image: { real: 'AUTHENTIC IMAGE', fake: 'AI-GENERATED IMAGE' },
  audio: { real: 'AUTHENTIC AUDIO', fake: 'SYNTHETIC VOICE DETECTED' },
  text: { real: 'HUMAN-WRITTEN TEXT', fake: 'AI-GENERATED TEXT' },
};

const VERDICT_DESCRIPTIONS: Record<MediaType, { real: string; fake: string }> = {
  video: {
    real: 'This video appears to be genuine and unmanipulated.',
    fake: 'This video shows signs of AI manipulation or generation.',
  },
  image: {
    real: 'This image appears to be authentic and unmanipulated.',
    fake: 'This image shows signs of AI generation or manipulation.',
  },
  audio: {
    real: 'This audio recording appears to be from a real human voice.',
    fake: 'This audio shows signs of synthetic voice generation or cloning.',
  },
  text: {
    real: 'This text appears to be written by a human.',
    fake: 'This text shows patterns consistent with AI generation.',
  },
};

export const AnalysisResult: React.FC<AnalysisResultProps> = ({ result, onReset }) => {
  const { mediaType, isReal, confidence, details, processingTime } = result;
  
  const MediaIcon = MEDIA_ICONS[mediaType];
  const verdictLabel = isReal ? VERDICT_LABELS[mediaType].real : VERDICT_LABELS[mediaType].fake;
  const verdictDescription = isReal ? VERDICT_DESCRIPTIONS[mediaType].real : VERDICT_DESCRIPTIONS[mediaType].fake;

  const detailItems = Object.entries(details).map(([key, value]) => ({
    label: getMetricLabel(key),
    value,
    icon: isReal ? CheckCircle2 : XCircle,
  }));

  const getProcessingInfo = () => {
    switch (mediaType) {
      case 'video':
        return `Frames analyzed: ${Math.floor(processingTime * 24)}`;
      case 'image':
        return `Pixels analyzed: ${Math.floor(processingTime * 1000000).toLocaleString()}`;
      case 'audio':
        return `Audio segments: ${Math.floor(processingTime * 10)}`;
      case 'text':
        return `Tokens analyzed: ${Math.floor(processingTime * 150)}`;
    }
  };

  return (
    <section className="py-20 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Result Card */}
        <div className={cn(
          "relative rounded-3xl p-8 md:p-12 overflow-hidden",
          "bg-card border",
          isReal ? "border-success/50" : "border-destructive/50"
        )}>
          {/* Background glow */}
          <div className={cn(
            "absolute inset-0 opacity-10",
            isReal 
              ? "bg-gradient-radial from-success via-transparent to-transparent" 
              : "bg-gradient-radial from-destructive via-transparent to-transparent"
          )} />

          {/* Content */}
          <div className="relative z-10">
            {/* Media Type Badge */}
            <div className="flex justify-center mb-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-muted text-muted-foreground text-sm">
                <MediaIcon className="w-4 h-4" />
                <span>{mediaType.charAt(0).toUpperCase() + mediaType.slice(1)} Analysis</span>
              </div>
            </div>

            {/* Status Icon */}
            <div className={cn(
              "w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center",
              isReal ? "bg-success/20 glow-success" : "bg-destructive/20 glow-destructive"
            )}>
              {isReal ? (
                <ShieldCheck className="w-12 h-12 text-success" />
              ) : (
                <ShieldAlert className="w-12 h-12 text-destructive" />
              )}
            </div>

            {/* Verdict */}
            <div className="text-center mb-8">
              <h2 className={cn(
                "font-display text-3xl md:text-4xl font-bold mb-2",
                isReal ? "text-success" : "text-destructive"
              )}>
                {verdictLabel}
              </h2>
              <p className="text-muted-foreground">
                {verdictDescription}
              </p>
            </div>

            {/* Confidence Score */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground">Confidence Score</span>
                <span className={cn(
                  "font-display text-2xl font-bold",
                  isReal ? "text-success" : "text-destructive"
                )}>
                  {confidence.toFixed(1)}%
                </span>
              </div>
              <Progress 
                value={confidence} 
                variant={isReal ? 'success' : 'destructive'}
                className="h-3"
              />
            </div>

            {/* Detailed Analysis */}
            <div className="space-y-4 mb-8">
              <h3 className="font-display text-sm font-semibold text-muted-foreground tracking-wider uppercase">
                Detailed Analysis
              </h3>
              
              <div className="grid gap-3">
                {detailItems.map((item, index) => (
                  <div 
                    key={index}
                    className="flex items-center justify-between p-4 rounded-xl bg-muted/50"
                  >
                    <div className="flex items-center gap-3">
                      <item.icon className={cn(
                        "w-5 h-5",
                        isReal ? "text-success" : "text-destructive"
                      )} />
                      <span className="text-sm font-medium text-foreground">{item.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress 
                        value={item.value} 
                        variant={isReal ? 'success' : 'destructive'}
                        className="w-20 h-2"
                      />
                      <span className={cn(
                        "text-sm font-mono font-medium w-12 text-right",
                        isReal ? "text-success" : "text-destructive"
                      )}>
                        {item.value.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Processing Info */}
            <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground mb-8 py-4 border-t border-b border-border">
              <span>Processing time: {processingTime.toFixed(1)}s</span>
              <span>•</span>
              <span>{getProcessingInfo()}</span>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                variant="glass" 
                size="lg" 
                className="flex-1"
                onClick={onReset}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Analyze Another
              </Button>
              <Button 
                variant={isReal ? 'success' : 'destructive'} 
                size="lg" 
                className="flex-1"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Report
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
