import React, { useState, useCallback, useRef } from 'react';
import { Upload, Video, Image, Mic, FileText, X, Play, Pause } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { MediaType, MEDIA_CONFIGS } from '@/types/media';

interface MediaUploaderProps {
  mediaType: MediaType;
  onMediaSelect: (file: File | null, text?: string) => void;
  isAnalyzing: boolean;
}

const ICONS: Record<MediaType, React.ElementType> = {
  video: Video,
  image: Image,
  audio: Mic,
  text: FileText,
};

export const MediaUploader: React.FC<MediaUploaderProps> = ({
  mediaType,
  onMediaSelect,
  isAnalyzing,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [textContent, setTextContent] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  const config = MEDIA_CONFIGS[mediaType];
  const MediaIcon = ICONS[mediaType];

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (mediaType !== 'text') setIsDragging(true);
  }, [mediaType]);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    if (mediaType === 'text') return;

    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelect(file);
    }
  }, [mediaType]);

  const handleFileSelect = (file: File) => {
    // Validate file type
    if (mediaType === 'video' && !file.type.startsWith('video/')) return;
    if (mediaType === 'image' && !file.type.startsWith('image/')) return;
    if (mediaType === 'audio' && !file.type.startsWith('audio/')) return;

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleClear = () => {
    setSelectedFile(null);
    setTextContent('');
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setPreviewUrl(null);
    setIsPlaying(false);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  const handleAnalyze = () => {
    if (mediaType === 'text') {
      onMediaSelect(null, textContent);
    } else if (selectedFile) {
      onMediaSelect(selectedFile);
    }
  };

  const toggleAudioPlayback = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const canAnalyze = mediaType === 'text' 
    ? textContent.trim().length > 50 
    : selectedFile !== null;

  const getAnalyzingText = () => {
    switch (mediaType) {
      case 'video': return 'ANALYZING FRAMES...';
      case 'image': return 'SCANNING PIXELS...';
      case 'audio': return 'ANALYZING WAVEFORM...';
      case 'text': return 'ANALYZING PATTERNS...';
    }
  };

  // Text input mode
  if (mediaType === 'text') {
    return (
      <section id="upload" className="py-20 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
              <span className="text-foreground">ANALYZE </span>
              <span className="text-gradient">TEXT</span>
            </h2>
            <p className="text-muted-foreground">
              Paste or type the text you want to analyze for AI-generated content.
            </p>
          </div>

          <div className="relative rounded-2xl border-2 border-border bg-card/50 p-4 transition-all duration-300 focus-within:border-primary/50">
            {isAnalyzing && (
              <div className="absolute inset-0 bg-background/80 rounded-2xl flex items-center justify-center z-10">
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full border-2 border-primary border-t-transparent animate-spin" />
                  <p className="font-display text-primary text-lg">{getAnalyzingText()}</p>
                </div>
              </div>
            )}

            <Textarea
              placeholder="Paste your text here (minimum 50 characters)..."
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              className="min-h-[200px] resize-none border-0 bg-transparent focus-visible:ring-0 text-base"
              disabled={isAnalyzing}
            />

            <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <FileText className="w-4 h-4" />
                <span>{textContent.length} / 50,000 characters</span>
              </div>

              <div className="flex gap-2">
                {textContent && (
                  <Button variant="ghost" size="sm" onClick={handleClear} disabled={isAnalyzing}>
                    <X className="w-4 h-4 mr-1" />
                    Clear
                  </Button>
                )}
                <Button
                  variant="hero"
                  size="lg"
                  onClick={handleAnalyze}
                  disabled={!canAnalyze || isAnalyzing}
                >
                  Analyze Text
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  // File upload mode (video, image, audio)
  return (
    <section id="upload" className="py-20 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            <span className="text-foreground">UPLOAD </span>
            <span className="text-gradient">{config.label.toUpperCase()}</span>
          </h2>
          <p className="text-muted-foreground">
            Drop your {config.label.toLowerCase()} file or click to browse. Supports {config.acceptedFormats}.
          </p>
        </div>

        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => !selectedFile && inputRef.current?.click()}
          className={cn(
            "relative rounded-2xl border-2 border-dashed transition-all duration-300 cursor-pointer overflow-hidden",
            isDragging
              ? "border-primary bg-primary/10 scale-[1.02]"
              : selectedFile
                ? "border-primary/50 bg-card"
                : "border-border hover:border-primary/50 bg-card/50",
            !selectedFile && "min-h-[300px] flex items-center justify-center"
          )}
        >
          <input
            ref={inputRef}
            type="file"
            accept={config.accept}
            onChange={handleInputChange}
            className="hidden"
            disabled={isAnalyzing}
          />

          {selectedFile && previewUrl ? (
            <div className="p-4">
              {/* Preview based on media type */}
              <div className="relative aspect-video rounded-xl overflow-hidden bg-muted mb-4">
                {mediaType === 'video' && (
                  <video
                    src={previewUrl}
                    className="w-full h-full object-contain"
                    controls={!isAnalyzing}
                  />
                )}

                {mediaType === 'image' && (
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="w-full h-full object-contain"
                  />
                )}

                {mediaType === 'audio' && (
                  <div className="w-full h-full flex flex-col items-center justify-center p-8">
                    <audio ref={audioRef} src={previewUrl} onEnded={() => setIsPlaying(false)} />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleAudioPlayback();
                      }}
                      disabled={isAnalyzing}
                      className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mb-4 hover:bg-primary/30 transition-colors"
                    >
                      {isPlaying ? (
                        <Pause className="w-10 h-10 text-primary" />
                      ) : (
                        <Play className="w-10 h-10 text-primary ml-1" />
                      )}
                    </button>
                    <div className="w-full max-w-md">
                      <div className="h-12 flex items-center justify-center gap-1">
                        {[...Array(40)].map((_, i) => (
                          <div
                            key={i}
                            className={cn(
                              "w-1 bg-primary rounded-full transition-all",
                              isPlaying ? "animate-pulse" : ""
                            )}
                            style={{
                              height: `${20 + Math.random() * 60}%`,
                              animationDelay: `${i * 50}ms`,
                            }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Scanning overlay when analyzing */}
                {isAnalyzing && (
                  <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                    <div className="relative w-full h-full">
                      <div className="absolute inset-0 scan-line animate-scan" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <div className="w-16 h-16 mx-auto mb-4 rounded-full border-2 border-primary border-t-transparent animate-spin" />
                          <p className="font-display text-primary text-lg">{getAnalyzingText()}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* File Info */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <MediaIcon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground truncate max-w-[200px] md:max-w-[400px]">
                      {selectedFile.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {formatFileSize(selectedFile.size)}
                    </p>
                  </div>
                </div>

                {!isAnalyzing && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleClear();
                    }}
                  >
                    <X className="w-5 h-5" />
                  </Button>
                )}
              </div>

              {/* Analyze Button */}
              {!isAnalyzing && (
                <Button
                  variant="hero"
                  size="xl"
                  className="w-full mt-4"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleAnalyze();
                  }}
                >
                  Start Deep Analysis
                </Button>
              )}
            </div>
          ) : (
            <div className="text-center p-8">
              <div
                className={cn(
                  "w-20 h-20 mx-auto mb-6 rounded-2xl flex items-center justify-center transition-all duration-300",
                  isDragging ? "bg-primary/20 scale-110" : "bg-primary/10"
                )}
              >
                <Upload
                  className={cn(
                    "w-10 h-10 transition-colors",
                    isDragging ? "text-primary" : "text-muted-foreground"
                  )}
                />
              </div>
              <p className="text-lg font-medium text-foreground mb-2">
                {isDragging ? `Drop your ${config.label.toLowerCase()} here` : `Drag & drop your ${config.label.toLowerCase()}`}
              </p>
              <p className="text-muted-foreground mb-4">or click to browse files</p>
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <MediaIcon className="w-4 h-4" />
                <span>{config.acceptedFormats} up to {config.maxSizeLabel}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
