import React, { useState, useEffect } from 'react';
import { ShieldIcon } from '@/components/icons/ShieldIcon';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  onGetStarted: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onGetStarted }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
      isScrolled ? "py-3 glass border-b border-border/50" : "py-6"
    )}>
      <div className="max-w-6xl mx-auto px-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <ShieldIcon className="w-8 h-8" />
          <span className="font-display text-xl font-bold hidden sm:inline">
            <span className="text-foreground">DEEP</span>
            <span className="text-gradient">DETECT</span>
          </span>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <a href="#how-it-works" className="text-sm text-muted-foreground hover:text-primary transition-colors">
            How It Works
          </a>
          <a href="#upload" className="text-sm text-muted-foreground hover:text-primary transition-colors">
            Upload
          </a>
          <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
            API
          </a>
          <Button variant="hero" size="sm" onClick={onGetStarted}>
            Get Started
          </Button>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? (
            <X className="w-6 h-6 text-foreground" />
          ) : (
            <Menu className="w-6 h-6 text-foreground" />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden glass border-t border-border/50 mt-3">
          <nav className="flex flex-col p-4 gap-4">
            <a 
              href="#how-it-works" 
              className="text-foreground hover:text-primary transition-colors py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              How It Works
            </a>
            <a 
              href="#upload" 
              className="text-foreground hover:text-primary transition-colors py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Upload
            </a>
            <a 
              href="#" 
              className="text-foreground hover:text-primary transition-colors py-2"
            >
              API
            </a>
            <Button 
              variant="hero" 
              className="mt-2"
              onClick={() => {
                setIsMobileMenuOpen(false);
                onGetStarted();
              }}
            >
              Get Started
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
};
