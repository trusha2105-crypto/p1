import React from 'react';

interface ShieldIconProps {
  className?: string;
}

export const ShieldIcon: React.FC<ShieldIconProps> = ({ className }) => {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Outer glow */}
      <defs>
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <linearGradient id="shieldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="hsl(187 100% 42%)" />
          <stop offset="100%" stopColor="hsl(263 70% 50%)" />
        </linearGradient>
      </defs>
      
      {/* Shield body */}
      <path
        d="M50 10 L85 25 L85 50 C85 70 70 85 50 95 C30 85 15 70 15 50 L15 25 Z"
        stroke="url(#shieldGradient)"
        strokeWidth="2"
        fill="none"
        filter="url(#glow)"
      />
      
      {/* Inner shield */}
      <path
        d="M50 18 L78 30 L78 48 C78 65 65 78 50 86 C35 78 22 65 22 48 L22 30 Z"
        stroke="url(#shieldGradient)"
        strokeWidth="1"
        fill="hsl(187 100% 42% / 0.1)"
        opacity="0.8"
      />
      
      {/* Eye/Scan symbol */}
      <ellipse
        cx="50"
        cy="50"
        rx="18"
        ry="12"
        stroke="hsl(187 100% 42%)"
        strokeWidth="2"
        fill="none"
        filter="url(#glow)"
      />
      
      {/* Pupil */}
      <circle
        cx="50"
        cy="50"
        r="6"
        fill="hsl(187 100% 42%)"
        filter="url(#glow)"
      />
      
      {/* Scan lines */}
      <line x1="30" y1="50" x2="38" y2="50" stroke="hsl(187 100% 42%)" strokeWidth="1" opacity="0.5" />
      <line x1="62" y1="50" x2="70" y2="50" stroke="hsl(187 100% 42%)" strokeWidth="1" opacity="0.5" />
    </svg>
  );
};
