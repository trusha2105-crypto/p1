import React from 'react';
import { Video, Image, Mic, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';
import { MediaType, MEDIA_CONFIGS } from '@/types/media';

interface MediaTypeSelectorProps {
  selected: MediaType;
  onSelect: (type: MediaType) => void;
  disabled?: boolean;
}

const ICONS: Record<MediaType, React.ElementType> = {
  video: Video,
  image: Image,
  audio: Mic,
  text: FileText,
};

export const MediaTypeSelector: React.FC<MediaTypeSelectorProps> = ({
  selected,
  onSelect,
  disabled = false,
}) => {
  const mediaTypes: MediaType[] = ['video', 'image', 'audio', 'text'];

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {mediaTypes.map((type) => {
          const config = MEDIA_CONFIGS[type];
          const Icon = ICONS[type];
          const isSelected = selected === type;

          return (
            <button
              key={type}
              onClick={() => onSelect(type)}
              disabled={disabled}
              className={cn(
                "relative flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-300",
                "hover:scale-[1.02] hover:shadow-lg",
                isSelected
                  ? "border-primary bg-primary/10 shadow-md shadow-primary/20"
                  : "border-border bg-card/50 hover:border-primary/50",
                disabled && "opacity-50 cursor-not-allowed hover:scale-100"
              )}
            >
              <div
                className={cn(
                  "p-3 rounded-lg transition-colors",
                  isSelected ? "bg-primary/20" : "bg-muted"
                )}
              >
                <Icon
                  className={cn(
                    "w-6 h-6 transition-colors",
                    isSelected ? "text-primary" : "text-muted-foreground"
                  )}
                />
              </div>
              <span
                className={cn(
                  "font-medium text-sm transition-colors",
                  isSelected ? "text-primary" : "text-foreground"
                )}
              >
                {config.label}
              </span>
              {isSelected && (
                <div className="absolute -bottom-px left-1/2 -translate-x-1/2 w-12 h-0.5 bg-primary rounded-full" />
              )}
            </button>
          );
        })}
      </div>
      
      {/* Description */}
      <p className="text-center text-muted-foreground text-sm mt-4">
        {MEDIA_CONFIGS[selected].description}
      </p>
    </div>
  );
};
