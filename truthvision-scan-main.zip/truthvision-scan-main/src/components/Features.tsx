import React from 'react';
import { Brain, Zap, Lock, Eye, Layers, BarChart3 } from 'lucide-react';
const features = [{
  icon: Brain,
  title: 'Neural Network Analysis',
  description: 'Deep CNN architecture trained on millions of real and fake videos for maximum accuracy.'
}, {
  icon: Eye,
  title: 'Face Detection',
  description: 'Advanced facial landmark detection identifies subtle inconsistencies in manipulated faces.'
}, {
  icon: Layers,
  title: 'Multi-Layer Scan',
  description: 'Analyzes temporal coherence, compression artifacts, and audio-visual synchronization.'
}, {
  icon: Zap,
  title: 'Real-Time Processing',
  description: 'Optimized inference engine delivers results in seconds, not minutes.'
}, {
  icon: BarChart3,
  title: 'Detailed Reports',
  description: 'Comprehensive breakdown of detection metrics with confidence scores.'
}, {
  icon: Lock,
  title: 'Privacy First',
  description: 'Videos are processed locally and automatically deleted after analysis.'
}];
export const Features: React.FC = () => {
  return;
};