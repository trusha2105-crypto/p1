import React from 'react';
import { Upload, Cpu, FileSearch, CheckCircle } from 'lucide-react';

const steps = [
  {
    icon: Upload,
    title: 'Upload',
    description: 'Drop your video file or select from your device. We support all common formats.',
  },
  {
    icon: FileSearch,
    title: 'Extract Frames',
    description: 'Our system extracts key frames from your video for detailed analysis.',
  },
  {
    icon: Cpu,
    title: 'AI Analysis',
    description: 'Advanced CNN models analyze facial patterns, temporal consistency, and artifacts.',
  },
  {
    icon: CheckCircle,
    title: 'Get Results',
    description: 'Receive a detailed report with confidence scores and detection insights.',
  },
];

export const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="py-20 px-4 bg-card/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            <span className="text-foreground">HOW IT </span>
            <span className="text-gradient">WORKS</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our advanced detection pipeline uses state-of-the-art neural networks 
            to identify manipulated media with exceptional accuracy.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <div 
              key={index}
              className="relative group"
            >
              {/* Connector line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-full w-full h-px bg-gradient-to-r from-primary/50 to-transparent z-0" />
              )}
              
              <div className="relative p-6 rounded-2xl bg-card border border-border hover:border-primary/50 transition-all duration-300 hover:-translate-y-1">
                {/* Step number */}
                <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-primary text-primary-foreground font-display font-bold text-sm flex items-center justify-center">
                  {index + 1}
                </div>
                
                {/* Icon */}
                <div className="w-14 h-14 mb-4 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <step.icon className="w-7 h-7 text-primary" />
                </div>
                
                {/* Content */}
                <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                  {step.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
