import React, { useState, useCallback, useRef } from 'react';
import { Upload, Video, X, FileVideo } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface VideoUploaderProps {
  onVideoSelect: (file: File) => void;
  isAnalyzing: boolean;
}

export const VideoUploader: React.FC<VideoUploaderProps> = ({ onVideoSelect, isAnalyzing }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('video/')) {
      handleFileSelect(file);
    }
  }, []);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleClear = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setPreviewUrl(null);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  const handleAnalyze = () => {
    if (selectedFile) {
      onVideoSelect(selectedFile);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <section id="upload" className="py-20 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            <span className="text-foreground">UPLOAD </span>
            <span className="text-gradient">VIDEO</span>
          </h2>
          <p className="text-muted-foreground">
            Drop your video file or click to browse. Supports MP4, WebM, and MOV formats.
          </p>
        </div>

        {/* Upload Zone */}
        <div
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => !selectedFile && inputRef.current?.click()}
          className={cn(
            "relative rounded-2xl border-2 border-dashed transition-all duration-300 cursor-pointer overflow-hidden",
            isDragging 
              ? "border-primary bg-primary/10 scale-[1.02]" 
              : selectedFile 
                ? "border-primary/50 bg-card" 
                : "border-border hover:border-primary/50 bg-card/50",
            !selectedFile && "min-h-[300px] flex items-center justify-center"
          )}
        >
          <input
            ref={inputRef}
            type="file"
            accept="video/*"
            onChange={handleInputChange}
            className="hidden"
            disabled={isAnalyzing}
          />

          {selectedFile && previewUrl ? (
            <div className="p-4">
              {/* Video Preview */}
              <div className="relative aspect-video rounded-xl overflow-hidden bg-muted mb-4">
                <video
                  src={previewUrl}
                  className="w-full h-full object-contain"
                  controls={!isAnalyzing}
                />
                
                {/* Scanning overlay when analyzing */}
                {isAnalyzing && (
                  <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                    <div className="relative w-full h-full">
                      <div className="absolute inset-0 scan-line animate-scan" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <div className="w-16 h-16 mx-auto mb-4 rounded-full border-2 border-primary border-t-transparent animate-spin" />
                          <p className="font-display text-primary text-lg">ANALYZING FRAMES...</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* File Info */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <FileVideo className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground truncate max-w-[200px] md:max-w-[400px]">
                      {selectedFile.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {formatFileSize(selectedFile.size)}
                    </p>
                  </div>
                </div>
                
                {!isAnalyzing && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleClear();
                    }}
                  >
                    <X className="w-5 h-5" />
                  </Button>
                )}
              </div>

              {/* Analyze Button */}
              {!isAnalyzing && (
                <Button
                  variant="hero"
                  size="xl"
                  className="w-full mt-4"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleAnalyze();
                  }}
                >
                  Start Deep Analysis
                </Button>
              )}
            </div>
          ) : (
            <div className="text-center p-8">
              <div className={cn(
                "w-20 h-20 mx-auto mb-6 rounded-2xl flex items-center justify-center transition-all duration-300",
                isDragging ? "bg-primary/20 scale-110" : "bg-primary/10"
              )}>
                <Upload className={cn(
                  "w-10 h-10 transition-colors",
                  isDragging ? "text-primary" : "text-muted-foreground"
                )} />
              </div>
              <p className="text-lg font-medium text-foreground mb-2">
                {isDragging ? "Drop your video here" : "Drag & drop your video"}
              </p>
              <p className="text-muted-foreground mb-4">
                or click to browse files
              </p>
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Video className="w-4 h-4" />
                <span>MP4, WebM, MOV up to 100MB</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
